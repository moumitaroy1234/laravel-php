<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthorsController extends Controller
{
  
   * @return 
   
  public function index()
  {
      
  }

  
   *
   * @return 
  public function create()
  {
      return view('addCategory');
  }

  
   * @param  
   * @return 
  public function store(Request $request)
  {
      $cat = new booksCategory;

      $cat->catName = $request->catName;

      $cat->save();
  }

  
   * @param  
   * @return 
  public function show(booksCategory $booksCategory)
  {
     
  }

  
   * @param  
   * @return 
  public function edit(booksCategory $booksCategory)
  {
      
  }

  /
   * @param  
   * @param  
   * @return 
   */
  public function update(Request $request, booksCategory $booksCategory)
  {
      
  }

  
   * @param  
   * @return 
   */
  public function destroy(booksCategory $booksCategory)
  {
      
  }
}
