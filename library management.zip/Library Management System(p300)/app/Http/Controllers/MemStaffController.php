<?php

namespace App\Http\Controllers;

use App\memStaff;
use Illuminate\Http\Request;

class MemStaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\memStaff  $memStaff
     * @return \Illuminate\Http\Response
     */
    public function show(memStaff $memStaff)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\memStaff  $memStaff
     * @return \Illuminate\Http\Response
     */
    public function edit(memStaff $memStaff)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\memStaff  $memStaff
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, memStaff $memStaff)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\memStaff  $memStaff
     * @return \Illuminate\Http\Response
     */
    public function destroy(memStaff $memStaff)
    {
        //
    }
}
