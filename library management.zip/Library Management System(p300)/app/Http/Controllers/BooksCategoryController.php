<?php

namespace App\Http\Controllers;

use App\booksCategory;
use Illuminate\Http\Request;

class BooksCategoryController extends Controller
{
   
     * @return 
    public function index()
    {
        $cats = booksCategory::all();
        return view('booksCat', ['cats' => $cats]);
    }

    
     * @return 
    public function create()
    {
        return view('addCategory');
    }

     * @param 
     * @return 
     */
    public function store(Request $request)
    {
        $cat = new booksCategory;

        $cat->catName = $request->catName;

        $cat->save();
    }

    
     * @param  \App\booksCategory  $booksCategory
     * @return \Illuminate\Http\Response
     */
    public function show(booksCategory $booksCategory)
    {
        //
    }

    /
     * @param  \App\booksCategory  $booksCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(booksCategory $booksCategory)
    {
        //
    }

    
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\booksCategory  $booksCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, booksCategory $booksCategory)
    {
        //
    }

    
     * @param  \App\booksCategory  $booksCategory
     * @return \Illuminate\Http\Response
     
    public function destroy(booksCategory $booksCategory)
    {
        
    }
}
