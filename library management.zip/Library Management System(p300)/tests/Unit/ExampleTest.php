<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ExampleTest extends TestCase
{
   
      @return 
     
    public function testBasicTest()
    {
        $this->assertTrue(true);
    }
}
