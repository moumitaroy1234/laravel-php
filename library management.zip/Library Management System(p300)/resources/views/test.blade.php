@extends('layouts.master')

@section('content')



  <div>
    This is test
    <multiselect v-model="value" :options="options"></multiselect>
  </div>

<script>
  import Multiselect from 'vue-multiselect'

  // register globally
  Vue.component('multiselect', Multiselect)

  export default {
    // OR register locally
    components: { Multiselect },
    data () {
      return {
        value: Haroon,
        options: ['list', 'of', 'options']
      }
    }
  }
</script>


<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>

<style>

</style>
@endsection
